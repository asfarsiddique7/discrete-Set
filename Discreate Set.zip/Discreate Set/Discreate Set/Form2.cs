﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Discreate_Set
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] planets1 = new string[listBox1.Items.Count];

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                planets1[i] = listBox1.Items[i].ToString();
            }

            string[] planets2 = new string[listBox2.Items.Count];

            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                planets2[i] = listBox2.Items[i].ToString();
            }


            // string[] planets1 = new string[listBox1.Items.ToString()];
           // string[] planets2 = { "Mercury", "Earth", "Mars", "Jupiter" };

            IEnumerable<string> query = from planet in planets1.Except(planets2)
                                        select planet;
            label7.Text = "{";
            foreach (var str in query)
            {
                label7.Text +="("+ str +")"+",";
            
                
            }

            label7.Text = label7.Text.Substring(0, label7.Text.Length - 1);
            
            label7.Text += "}";
            if (label7.Text == "}")
            {
                label7.Text = "Φ";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] planets1 = new string[listBox1.Items.Count];

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                planets1[i] = listBox1.Items[i].ToString();
            }

            string[] planets2 = new string[listBox2.Items.Count];

            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                planets2[i] = listBox2.Items[i].ToString();
            }


            // string[] planets1 = new string[listBox1.Items.ToString()];
            // string[] planets2 = { "Mercury", "Earth", "Mars", "Jupiter" };

            IEnumerable<string> query = from planet in planets2.Except(planets1)
                                        select planet;

            label7.Text = "{";
            foreach (var str in query)
            {
                label7.Text += "(" + str + ")" + ",";
            }
            label7.Text = label7.Text.Substring(0, label7.Text.Length - 1);

            label7.Text += "}";
            if (label7.Text == "}")
            {
                label7.Text = "Φ";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] planets1 = new string[listBox1.Items.Count];

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                planets1[i] = listBox1.Items[i].ToString();
            }

            string[] planets2 = new string[listBox2.Items.Count];

            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                planets2[i] = listBox2.Items[i].ToString();
            }


            // string[] planets1 = new string[listBox1.Items.ToString()];
            // string[] planets2 = { "Mercury", "Earth", "Mars", "Jupiter" };

            IEnumerable<string> query = from planet in planets1.Intersect(planets2)
                                        select planet;

            label7.Text = "{";
            foreach (var str in query)
            {
                label7.Text += "(" + str + ")" + ",";
            }
            label7.Text = label7.Text.Substring(0, label7.Text.Length - 1);

            label7.Text += "}";
            if (label7.Text == "}")
            {
                label7.Text = "Φ";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string[] planets1 = new string[listBox1.Items.Count];

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                planets1[i] = listBox1.Items[i].ToString();
            }

            string[] planets2 = new string[listBox2.Items.Count];

            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                planets2[i] = listBox2.Items[i].ToString();
            }


            // string[] planets1 = new string[listBox1.Items.ToString()];
            // string[] planets2 = { "Mercury", "Earth", "Mars", "Jupiter" };

            IEnumerable<string> query = from planet in planets1.Union(planets2)
                                        select planet;
            label7.Text = "{";
            foreach (var str in query)
            {
                label7.Text += "(" + str + ")" + ",";
            }
            label7.Text = label7.Text.Substring(0, label7.Text.Length - 1);

            label7.Text += "}";
            if (label7.Text == "}")
            {
                label7.Text = "Φ";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text != "")
            {
                listBox1.Items.Add(this.textBox1.Text);
                this.textBox1.Focus();
                this.textBox1.Clear();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (this.textBox2.Text != "")
            {
                listBox2.Items.Add(this.textBox2.Text);
                this.textBox2.Focus();
                this.textBox2.Clear();

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string[] planets1 = new string[listBox1.Items.Count];

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                planets1[i] = listBox1.Items[i].ToString();
            }

            string[] planets2 = new string[listBox2.Items.Count];

            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                planets2[i] = listBox2.Items[i].ToString();
            }


            // string[] planets1 = new string[listBox1.Items.ToString()];
            // string[] planets2 = { "Mercury", "Earth", "Mars", "Jupiter" };

            IEnumerable<string> query = from planet in planets1.Except(planets2)
                                        select planet;
            label7.Text = "{";
            foreach (var str in query)
            {
                label7.Text += "(" + str + ")" + ",";


            }

            label7.Text = label7.Text.Substring(0, label7.Text.Length - 1);

            label7.Text += "}";
            if (label7.Text == "}")
            {
                label7.Text = "Φ";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            label7.Text = "";
        }
    }
}
